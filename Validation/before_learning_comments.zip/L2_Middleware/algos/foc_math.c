#include "foc_math.h"
#include <math.h>

/* raw 为同一采样周期的原始码；cal 只读，current 由本算子写入，成功返回 1。 */
int Foc_CurrentSample(uint16_t raw_a, uint16_t raw_b,
                      const FocCurrentCalibration *cal, FocPhaseCurrent *current)
{
    *current = (FocPhaseCurrent){0.0f, 0.0f, 0.0f};
    if (cal->adc_max_count == 0 || raw_a > cal->adc_max_count ||
        raw_b > cal->adc_max_count ||
        !isfinite(cal->offset_a_count) || !isfinite(cal->offset_b_count) ||
        cal->offset_a_count < 0.0f || cal->offset_a_count > cal->adc_max_count ||
        cal->offset_b_count < 0.0f || cal->offset_b_count > cal->adc_max_count ||
        !isfinite(cal->amp_per_count_a) || !isfinite(cal->amp_per_count_b) ||
        cal->amp_per_count_a == 0.0f || cal->amp_per_count_b == 0.0f) {
        return 0;
    }

    /* I = (ADC - offset) * Vref / (ADC满码 * Rshunt * Gain)。 */
    current->a = ((float)raw_a - cal->offset_a_count) * cal->amp_per_count_a;
    current->b = ((float)raw_b - cal->offset_b_count) * cal->amp_per_count_b;
    current->c = -current->a - current->b;
    if (!isfinite(current->a) || !isfinite(current->b) || !isfinite(current->c)) {
        *current = (FocPhaseCurrent){0.0f, 0.0f, 0.0f};
        return 0;
    }
    return 1;
}

/* 输入三相电流 A，使用两电阻形式，输出幅值不变的 alpha/beta 电流 A。 */
FocAlphaBeta Foc_Clarke(FocPhaseCurrent current)
{
    FocAlphaBeta result;
    result.alpha = current.a;
    result.beta = (current.a + 2.0f * current.b) * FOC_INV_SQRT3;
    return result;
}

/* 将静止电流投影到转子 d/q 轴；sin/cos 对应电流采样时刻的电角度。 */
FocDq Foc_Park(FocAlphaBeta current, float sin_theta, float cos_theta)
{
    FocDq result;
    result.d = current.alpha * cos_theta + current.beta * sin_theta;
    result.q = -current.alpha * sin_theta + current.beta * cos_theta;
    return result;
}

/* 矩形离散积分：integral[k]=integral[k-1]+Ki*e[k]*Ts；更新调用者的轴状态。 */
float Foc_PiStep(float error_a, float period_s, FocPiGains gains, FocPiState *state)
{
    state->integral_v += gains.ki * error_a * period_s;
    return gains.kp * error_a + state->integral_v;
}

/* 合成 d/q 电压 V，再按幅值 limit_v 等比例缩小；归一化计算避免平方溢出。 */
int Foc_VoltageLimit(FocDq pi_v, FocDq feedforward_v, float limit_v,
                     FocDq *requested_v, FocDq *limited_v, float *scale)
{
    float peak;
    float norm;
    *limited_v = (FocDq){0.0f, 0.0f};
    *scale = 0.0f;
    requested_v->d = pi_v.d + feedforward_v.d;
    requested_v->q = pi_v.q + feedforward_v.q;
    if (!isfinite(requested_v->d) || !isfinite(requested_v->q) ||
        !isfinite(limit_v) || limit_v <= 0.0f) {
        return 0;
    }

    peak = fmaxf(fabsf(requested_v->d), fabsf(requested_v->q));
    *scale = 1.0f;
    if (peak > 0.0f) {
        norm = sqrtf((requested_v->d / peak) * (requested_v->d / peak) +
                     (requested_v->q / peak) * (requested_v->q / peak));
        if (peak > limit_v / norm) {
            *scale = (limit_v / peak) / norm;
        }
    }
    limited_v->d = requested_v->d * *scale;
    limited_v->q = requested_v->q * *scale;
    return 1;
}

/* 将 d/q 电压 V 旋回 alpha/beta；sin/cos 对应预计电压生效时刻的电角度。 */
FocAlphaBeta Foc_InversePark(FocDq voltage, float sin_theta, float cos_theta)
{
    FocAlphaBeta result;
    result.alpha = voltage.d * cos_theta - voltage.q * sin_theta;
    result.beta = voltage.d * sin_theta + voltage.q * cos_theta;
    return result;
}

/* 反 Clarke + 极值共模注入，得到上桥臂占空比；允许 2e-6 的浮点边界误差。 */
int Foc_Svpwm(FocAlphaBeta voltage, float bus_v, FocSvpwm *pwm)
{
    float vmax;
    float vmin;
    FocSvpwm result = {0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.5f, 0.5f};
    *pwm = result;
    if (!isfinite(voltage.alpha) || !isfinite(voltage.beta) ||
        !isfinite(bus_v) || bus_v <= 0.0f) {
        return 0;
    }

    result.phase_a_v = voltage.alpha;
    result.phase_b_v = -0.5f * voltage.alpha + FOC_SQRT3_OVER_2 * voltage.beta;
    result.phase_c_v = -0.5f * voltage.alpha - FOC_SQRT3_OVER_2 * voltage.beta;
    vmax = fmaxf(result.phase_a_v, fmaxf(result.phase_b_v, result.phase_c_v));
    vmin = fminf(result.phase_a_v, fminf(result.phase_b_v, result.phase_c_v));
    result.common_v = -0.5f * vmax - 0.5f * vmin;
    result.duty_a = 0.5f + (result.phase_a_v + result.common_v) / bus_v;
    result.duty_b = 0.5f + (result.phase_b_v + result.common_v) / bus_v;
    result.duty_c = 0.5f + (result.phase_c_v + result.common_v) / bus_v;
    if (!isfinite(result.duty_a) || !isfinite(result.duty_b) || !isfinite(result.duty_c) ||
        result.duty_a < -0.000002f || result.duty_a > 1.000002f ||
        result.duty_b < -0.000002f || result.duty_b > 1.000002f ||
        result.duty_c < -0.000002f || result.duty_c > 1.000002f) {
        return 0;
    }
    result.duty_a = fminf(1.0f, fmaxf(0.0f, result.duty_a));
    result.duty_b = fminf(1.0f, fmaxf(0.0f, result.duty_b));
    result.duty_c = fminf(1.0f, fmaxf(0.0f, result.duty_c));
    *pwm = result;
    return 1;
}
