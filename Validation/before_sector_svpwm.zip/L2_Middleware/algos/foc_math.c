#include "foc_math.h"
#include <math.h>

/*
 * 电流采样换算，对应总框图 ADC -> Clarke 之间的数据准备。
 * raw 为同一采样周期的原始码；cal 只读，current 输出 A，成功返回 1。
 * 零电流也可能对应非零 ADC 码，所以先扣 offset，再乘 A/count 标度。
 * 第 01 课“三相相轴与平衡条件”：三线制、无零序时 Ia+Ib+Ic=0。
 * 本算子据此重构 Ic，不代表实际测量了第三相，也不执行 ADC 外设采集。
 */
int Foc_CurrentSample(uint16_t raw_a, uint16_t raw_b,
                      const FocCurrentCalibration *cal, FocPhaseCurrent *current)
{
    *current = (FocPhaseCurrent){0.0f, 0.0f, 0.0f};
    if (cal->adc_max_count == 0 || raw_a > cal->adc_max_count ||
        raw_b > cal->adc_max_count ||
        !isfinite(cal->offset_a_count) || !isfinite(cal->offset_b_count) ||
        cal->offset_a_count < 0.0f || cal->offset_a_count > cal->adc_max_count ||
        cal->offset_b_count < 0.0f || cal->offset_b_count > cal->adc_max_count ||
        !isfinite(cal->amp_per_count_a) || !isfinite(cal->amp_per_count_b) ||
        cal->amp_per_count_a == 0.0f || cal->amp_per_count_b == 0.0f) {
        return 0;
    }

    /* I = (ADC - offset) * Vref / (ADC满码 * Rshunt * Gain)。 */
    current->a = ((float)raw_a - cal->offset_a_count) * cal->amp_per_count_a;
    current->b = ((float)raw_b - cal->offset_b_count) * cal->amp_per_count_b;
    current->c = -current->a - current->b;
    if (!isfinite(current->a) || !isfinite(current->b) || !isfinite(current->c)) {
        *current = (FocPhaseCurrent){0.0f, 0.0f, 0.0f};
        return 0;
    }
    return 1;
}

/*
 * 第 01 课“四、Clarke 变换”：三相电流 A -> 定子静止 alpha/beta 电流 A。
 * 幅值不变形式：Ialpha=(2/3)*(Ia-Ib/2-Ic/2)，Ibeta=(Ib-Ic)/sqrt(3)。
 * 代入 Ic=-Ia-Ib，得到下面的二电流形式；alpha 与 A 相轴重合。
 * “幅值不变”指平衡正弦三相的相电流峰值等于 alpha/beta 矢量幅值，
 * 不是把三相瞬时数值原样复制；这里只改变坐标表示，不改变真实绕组电流。
 * 讲义例：Ia=8.660 A、Ib=0 A -> Ialpha=8.660 A、Ibeta 约 5 A。
 */
FocAlphaBeta Foc_Clarke(FocPhaseCurrent current)
{
    FocAlphaBeta result;
    result.alpha = current.a;
    result.beta = (current.a + 2.0f * current.b) * FOC_INV_SQRT3;
    return result;
}

/*
 * 第 01 课“五、Park 变换”：把静止电流投影到随转子磁链旋转的 d/q 轴。
 * [Id] = [ cos(theta_e)  sin(theta_e)] [Ialpha]
 * [Iq]   [-sin(theta_e)  cos(theta_e)] [Ibeta ]
 * d 轴单位方向为 (cos,sin)，q 轴超前 90°，单位方向为 (-sin,cos)。
 * 因而 d/q 是同一电流矢量的两个投影，不是另外两根物理绕组的电流。
 * sin/cos 对应采样时刻的电角度，不能直接把机械角或角度制数值当作输入。
 * 讲义例：Ialpha=8.660、Ibeta 约 5，theta_e=300° -> Id 约 0、Iq 约 10 A。
 */
FocDq Foc_Park(FocAlphaBeta current, float sin_theta, float cos_theta)
{
    FocDq result;
    result.d = current.alpha * cos_theta + current.beta * sin_theta;
    result.q = -current.alpha * sin_theta + current.beta * cos_theta;
    return result;
}

/*
 * 第 02 课“三、dq 电流 PI”：电流误差 A -> 用于纠偏的电压指令 V。
 * 连续式 U=Kp*e+Ki*积分(e dt)，下面按每个采样周期进行矩形离散积分：
 * Ui_trial[k]=Ui[k-1]+Ki*e[k]*Ts，U[k]=Kp*e[k]+Ui_trial[k]。
 * error_a 是目标减反馈；period_s 为 Ts（秒），ki 尚未预乘 Ts，不能重复乘。
 * state 保存本轴唯一积分电压历史，每个有效周期更新一次；输出不是电流或占空比。
 * 两轴合成限幅之后，整链还会回算修正积分，所以本函数不独自做轴向电压截断。
 */
float Foc_PiStep(float error_a, float period_s, FocPiGains gains, FocPiState *state)
{
    state->integral_v += gains.ki * error_a * period_s;
    return gains.kp * error_a + state->integral_v;
}

/*
 * 第 07 课“四、模型解耦”与第 08 课“7. 电压限幅怎样进入 MCU 控制链”。
 * 先合成：Vd*=Ud+Vd_ff，Vq*=Uq+Vq_ff；pi_v 对应 Ud/Uq，前馈由调用者提供。
 * 再限幅：|V*|=sqrt(Vd*²+Vq*²)，k=min(1,Vlimit/|V*|)，Vlim=k*V*。
 * requested_v 保存限幅前电压，limited_v 保存限幅后电压，scale 输出 k。
 * 两轴乘同一个 k，所以保持矢量方向；不能把 d/q 分别截到 +/-Vlimit。
 * limit_v 是调用者按实际母线提供的圆形边界，零矢量无需缩放，k=1。
 */
int Foc_VoltageLimit(FocDq pi_v, FocDq feedforward_v, float limit_v,
                     FocDq *requested_v, FocDq *limited_v, float *scale)
{
    float peak;
    float norm;
    *limited_v = (FocDq){0.0f, 0.0f};
    *scale = 0.0f;
    requested_v->d = pi_v.d + feedforward_v.d;
    requested_v->q = pi_v.q + feedforward_v.q;
    if (!isfinite(requested_v->d) || !isfinite(requested_v->q) ||
        !isfinite(limit_v) || limit_v <= 0.0f) {
        return 0;
    }

    /* peak 是最大轴分量绝对值，不是矢量幅值；先归一化可避免大数直接平方溢出。 */
    peak = fmaxf(fabsf(requested_v->d), fabsf(requested_v->q));
    *scale = 1.0f;
    if (peak > 0.0f) {
        /* norm=|V*|/peak；下面的比较及缩放仍等价于讲义中的 |V*|>Vlimit 和 k。 */
        norm = sqrtf((requested_v->d / peak) * (requested_v->d / peak) +
                     (requested_v->q / peak) * (requested_v->q / peak));
        if (peak > limit_v / norm) {
            *scale = (limit_v / peak) / norm;
        }
    }
    limited_v->d = requested_v->d * *scale;
    limited_v->q = requested_v->q * *scale;
    return 1;
}

/*
 * 第 02 课“四、反 Park”：旋转 d/q 电压 V -> 静止 alpha/beta 电压 V。
 * [Valpha] = [cos(theta_e) -sin(theta_e)] [Vd]
 * [Vbeta ]   [sin(theta_e)  cos(theta_e)] [Vq]
 * 这是 Park 矩阵的逆（转置），正负号必须与 Foc_Park 配套；正交变换保持幅值。
 * SVPWM 的开关矢量固定在定子坐标中，所以要先转回 alpha/beta，不能将 d/q 直接配给 A/B 相。
 * 第 02/06 课的时序约定：这里 sin/cos 对应预计电压生效时刻，可能不同于采样角。
 */
FocAlphaBeta Foc_InversePark(FocDq voltage, float sin_theta, float cos_theta)
{
    FocAlphaBeta result;
    result.alpha = voltage.d * cos_theta - voltage.q * sin_theta;
    result.beta = voltage.d * sin_theta + voltage.q * cos_theta;
    return result;
}

/*
 * 第 02 课“五、两电平逆变器”及“六、SVPWM”：静止电压 V -> 上桥臂占空比。
 * 讲义用相邻有效矢量的 T1/T2 与零矢量 T0 合成一个周期的平均电压；
 * 这里采用该课提到的“公共模注入/最值零序偏移”法，直接求居中占空比。
 * 在理想两电平桥的线性范围内，它与对称零矢量分配的占空结果等价。
 * 本算子不决定定时器开关序列、死区或互锁，仅计算相参考电压与占空比。
 * bus_v 是实际母线电压 V；成功写 pwm 并返回 1，失败输出中性值并返回 0。
 */
int Foc_Svpwm(FocAlphaBeta voltage, float bus_v, FocSvpwm *pwm)
{
    float vmax;
    float vmin;
    FocSvpwm result = {0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.5f, 0.5f};
    *pwm = result;
    if (!isfinite(voltage.alpha) || !isfinite(voltage.beta) ||
        !isfinite(bus_v) || bus_v <= 0.0f) {
        return 0;
    }

    /* ① 反 Clarke：把 alpha/beta 参考矢量投影回相隔 120° 的 A/B/C 相轴。 */
    result.phase_a_v = voltage.alpha;
    result.phase_b_v = -0.5f * voltage.alpha + FOC_SQRT3_OVER_2 * voltage.beta;
    result.phase_c_v = -0.5f * voltage.alpha - FOC_SQRT3_OVER_2 * voltage.beta;
    /* ② 三相同加 Voff=-(Vmax+Vmin)/2，使最高/最低相关于 0 对称。
     * 任意相间电压差不变：(Va+Voff)-(Vb+Voff)=Va-Vb。
     */
    vmax = fmaxf(result.phase_a_v, fmaxf(result.phase_b_v, result.phase_c_v));
    vmin = fminf(result.phase_a_v, fminf(result.phase_b_v, result.phase_c_v));
    result.common_v = -0.5f * vmax - 0.5f * vmin;
    /* ③ Dx=0.5+(Vx+Voff)/Vdc；三相参考为零时得到 (0.5,0.5,0.5)。
     * 第一扇区 Va>=Vb>=Vc 时，令 t1=T1/Ts、t2=T2/Ts、t0=1-t1-t2：
     * Da=t1+t2+t0/2，Db=t2+t0/2，Dc=t0/2；故 t1=Da-Db，t2=Db-Dc。
     * 这就是讲义作用时间公式与此处占空比公式的对应关系，其他扇区改变相序。
     */
    result.duty_a = 0.5f + (result.phase_a_v + result.common_v) / bus_v;
    result.duty_b = 0.5f + (result.phase_b_v + result.common_v) / bus_v;
    result.duty_c = 0.5f + (result.phase_c_v + result.common_v) / bus_v;
    /* 超过线性占空范围时拒绝输入；只容忍 2e-6 的浮点边界误差，不做过调制。 */
    if (!isfinite(result.duty_a) || !isfinite(result.duty_b) || !isfinite(result.duty_c) ||
        result.duty_a < -0.000002f || result.duty_a > 1.000002f ||
        result.duty_b < -0.000002f || result.duty_b > 1.000002f ||
        result.duty_c < -0.000002f || result.duty_c > 1.000002f) {
        return 0;
    }
    result.duty_a = fminf(1.0f, fmaxf(0.0f, result.duty_a));
    result.duty_b = fminf(1.0f, fmaxf(0.0f, result.duty_b));
    result.duty_c = fminf(1.0f, fmaxf(0.0f, result.duty_c));
    *pwm = result;
    return 1;
}
