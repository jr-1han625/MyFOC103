#include "foc_control.h"
#include <math.h>
#include <string.h>

FocControl foc;

/* 初始化唯一对象；未配置硬件标度/周期/增益前保持停机，占空比只作中性显示。 */
void Foc_Init(void)
{
    memset(&foc, 0, sizeof(foc));
    foc.pwm.duty_a = 0.5f;
    foc.pwm.duty_b = 0.5f;
    foc.pwm.duty_c = 0.5f;
    foc.status = FOC_DISABLED;
}

/* 消费一次采样快照，按总框图顺序计算；失败清积分和本周期输出，返回失败原因。 */
FocStatus Foc_ControlStep(const FocSample *sample)
{
    float sin_sample;
    float cos_sample;
    float sin_output;
    float cos_output;

    foc.valid = 0;
    if (foc.enabled == 0) {
        foc.status = FOC_DISABLED;
        goto inactive;
    }
    if (foc.enabled != 1 || !isfinite(foc.period_s) || foc.period_s <= 0.0f ||
        !isfinite(foc.voltage_utilization) || foc.voltage_utilization <= 0.0f ||
        foc.voltage_utilization > 1.0f ||
        !isfinite(foc.gains_d.kp) || foc.gains_d.kp < 0.0f ||
        !isfinite(foc.gains_d.ki) || foc.gains_d.ki < 0.0f ||
        !isfinite(foc.gains_q.kp) || foc.gains_q.kp < 0.0f ||
        !isfinite(foc.gains_q.ki) || foc.gains_q.ki < 0.0f ||
        !isfinite(foc.reference_a.d) || !isfinite(foc.reference_a.q) ||
        !isfinite(foc.feedforward_v.d) || !isfinite(foc.feedforward_v.q)) {
        foc.status = FOC_INVALID_CONFIG;
        goto inactive;
    }
    if (!isfinite(sample->bus_v) || sample->bus_v <= 0.0f ||
        !isfinite(sample->sample_angle_rad) || !isfinite(sample->output_angle_rad)) {
        foc.status = FOC_INVALID_SAMPLE;
        goto inactive;
    }

    /* 1. 同一 PWM 周期的 ADC 原始码 -> 扣零点、换算 A、重构 Ic。 */
    if (!Foc_CurrentSample(sample->raw_a, sample->raw_b,
                           &foc.calibration, &foc.current_a)) {
        foc.status = FOC_INVALID_SAMPLE;
        goto inactive;
    }

    /* 2. 幅值不变 Clarke：Ialpha=Ia，Ibeta=(Ia+2Ib)/sqrt(3)。 */
    foc.current_ab_a = Foc_Clarke(foc.current_a);

    /* 3. Park：采样时刻的电角度将静止电流投影到转子坐标。 */
    sin_sample = sinf(sample->sample_angle_rad);
    cos_sample = cosf(sample->sample_angle_rad);
    foc.current_dq_a = Foc_Park(foc.current_ab_a, sin_sample, cos_sample);

    /* 4. 双轴电流 PI：e=Iref-I，Vpi=Kp*e+积分(Ki*e*Ts)。 */
    foc.error_a.d = foc.reference_a.d - foc.current_dq_a.d;
    foc.error_a.q = foc.reference_a.q - foc.current_dq_a.q;
    foc.pi_v.d = Foc_PiStep(foc.error_a.d, foc.period_s, foc.gains_d, &foc.pi_d);
    foc.pi_v.q = Foc_PiStep(foc.error_a.q, foc.period_s, foc.gains_q, &foc.pi_q);

    /* 5. 合成/限幅：基础链前馈为零；保留方向，半径不超过 Vdc/sqrt(3)。 */
    foc.voltage_limit_v = sample->bus_v * FOC_INV_SQRT3 * foc.voltage_utilization;
    if (!Foc_VoltageLimit(foc.pi_v, foc.feedforward_v, foc.voltage_limit_v,
                          &foc.requested_v, &foc.limited_v, &foc.voltage_scale)) {
        foc.status = FOC_NUMERIC_ERROR;
        goto inactive;
    }

    /* 抗积分饱和：I[k] += Vapplied - Vrequested，校正作用于下一周期。
     * 两轴都跟踪实际矢量限幅结果，包含前馈影响；未限幅时修正量为零。
     */
    foc.pi_d.integral_v += foc.limited_v.d - foc.requested_v.d;
    foc.pi_q.integral_v += foc.limited_v.q - foc.requested_v.q;
    if (!isfinite(foc.pi_d.integral_v) || !isfinite(foc.pi_q.integral_v)) {
        foc.status = FOC_NUMERIC_ERROR;
        goto inactive;
    }

    /* 6. 反 Park：可由调用者提供补偿后的电压生效角度；无补偿时与采样角相同。 */
    sin_output = sinf(sample->output_angle_rad);
    cos_output = cosf(sample->output_angle_rad);
    foc.voltage_ab_v = Foc_InversePark(foc.limited_v, sin_output, cos_output);

    /* 7. SVPWM：反 Clarke -> 极值共模注入 -> 三相占空比。 */
    if (!Foc_Svpwm(foc.voltage_ab_v, sample->bus_v, &foc.pwm)) {
        foc.status = FOC_NUMERIC_ERROR;
        goto inactive;
    }
    foc.status = FOC_OK;
    foc.valid = 1;
    return foc.status;

inactive:
    foc.pi_d.integral_v = 0.0f;
    foc.pi_q.integral_v = 0.0f;
    foc.current_a = (FocPhaseCurrent){0.0f, 0.0f, 0.0f};
    foc.current_ab_a = (FocAlphaBeta){0.0f, 0.0f};
    foc.current_dq_a = (FocDq){0.0f, 0.0f};
    foc.error_a = (FocDq){0.0f, 0.0f};
    foc.pi_v = (FocDq){0.0f, 0.0f};
    foc.requested_v = (FocDq){0.0f, 0.0f};
    foc.limited_v = (FocDq){0.0f, 0.0f};
    foc.voltage_limit_v = 0.0f;
    foc.voltage_scale = 0.0f;
    foc.voltage_ab_v = (FocAlphaBeta){0.0f, 0.0f};
    foc.pwm = (FocSvpwm){0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.5f, 0.5f};
    return foc.status;
}
